$(function () {
    /* JQUERY TIMEAGO */
    jQuery("time.timeago").timeago();
});