<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['facebook']['api_id']       = '141250066463038';
$config['facebook']['app_secret']   = 'cda278f124f1f3ea730876acf49741c9';
$config['facebook']['redirect_url'] = 'http://beta.tamnews.id/';
$config['facebook']['permissions']  = array(
                                        'email',
                                        'user_location',
                                        'user_birthday'
                                      );


/* End of file facebook.php */
/* Location: ./application/config/facebook.php */